from django.shortcuts import render,redirect
from django.http import HttpResponse
from django.contrib.auth.decorators import login_required
from .forms import PostForm,CourseForm
from .filters import PostFilter,CourseFilter
from .models import Post,Course
from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger
from django.core.mail import EmailMessage
from django.conf import settings
from django.template.loader import render_to_string
# Create your views here.

def home(request):
    courses=Course.objects.filter(active=True,featured=True)[0:6]
    posts=Post.objects.filter(active=True,featured=True)[0:3]
    context={'posts':posts,'courses':courses}
    return render(request,'base/index.html',context)

def posts(request):
    posts=Post.objects.filter(active=True)
    myFilter=PostFilter(request.GET,queryset=posts)
    posts=myFilter.qs
    page=request.GET.get('page')
    paginator=Paginator(posts,6)
    try:
        posts=paginator.page(page)
    except PageNotAnInteger:
        posts=paginator.page(1)
    except EmptyPage:
        posts=paginator.page(paginator.num_pages)
    context={'posts':posts,'myFilter':myFilter}
    return render(request,'base/posts.html',context)

def courses(request):
    courses=Course.objects.filter(active=True)
    myFilter=CourseFilter(request.GET,queryset=courses)
    courses=myFilter.qs
    page=request.GET.get('page')
    paginator=Paginator(courses,6)
    try:
        courses=paginator.page(page)
    except PageNotAnInteger:
        courses=paginator.page(1)
    except EmptyPage:
        courses=paginator.page(paginator.num_pages)
    context={'courses':courses,'myFilter':myFilter}
    return render(request,'base/courses.html',context)

def course(request,slug):
    course=Course.objects.get(slug=slug)
    context={'course':course}
    return render(request,'base/course.html',context)

def post(request,slug):
    post=Post.objects.get(slug=slug)
    context={'post':post}
    return render(request,'base/post.html',context)

def profile(request):
    return render(request,'base/profile.html')

#CRUD views
@login_required(login_url="home")
def createPost(request):
    form=PostForm()
    if request.method=='POST':
        form=PostForm(request.POST,request.FILES)
        if form.is_valid():
            form.save()
        return redirect('posts')
    context={'form':form}
    return render(request,'base/post_form.html',context)

@login_required(login_url="home")
def updatePost(request,slug):
    post=Post.objects.get(slug=slug)
    form=PostForm(instance=post)
    if request.method=='POST':
        form=PostForm(request.POST,request.FILES,instance=post)
        if form.is_valid():
            form.save()
        return redirect('posts')
    context={'form':form}
    return render(request,'base/post_form.html',context)

@login_required(login_url="home")
def deletePost(request,slug):
    post=Post.objects.get(slug=slug)
    if request.method=='POST':
        post.delete()
        return redirect('posts')
    context={'item':post}
    return render(request,'base/delete.html',context)


@login_required(login_url="home")
def createCourse(request):
    form=CourseForm()
    if request.method=="POST":
        form=CourseForm(request.POST,request.FILES)
        if form.is_valid():
            form.save()
        return redirect('courses')
    context={'form':form}
    return render(request,'base/course_form.html',context)

@login_required(login_url="home")
def updateCourse(request,slug):
    course=Course.objects.get(slug=slug)
    form=CourseForm(instance=course)
    if request.method=="POST":
        form=CourseForm(request.POST,request.FILES,instance=course)
        if form.is_valid:
            form.save()
        return redirect('courses')
    context={'form':form}
    return render(request,'base/course_form.html',context)

@login_required(login_url="home")
def deleteCourse(request,slug):
    course=Course.objects.get(slug=slug)
    if request.method=="POST":
        course.delete()
        return redirect('courses')
    context={'course':course}
    return render(request,'base/deletecourse.html',context)

def sendEmail(request):
    if request.method=='POST':
        template=render_to_string('base/email_template.html',{
          'name':request.POST['name'],
          'email':request.POST['email'],
          'message':request.POST['message'],
          })
        email=EmailMessage(
          request.POST['subject'],
          template,
          settings.EMAIL_HOST_USER,
          ['malluriaravindreddy@gmail.com']
          )
        email.fail_silently=False
        email.send()

    return render(request,'base/email_sent.html')

def subscribe(request):
    if request.method=='POST':
        template=render_to_string('base/subscribe.html',{
          'email':request.POST['email'],
          })
        email=EmailMessage(
         request.POST['email'],
         template,
         settings.EMAIL_HOST_USER,
         ['malluriaravindreddy@gmail.com']
         )
        email.fail_silently=False
        email.send()

    return render(request,'base/subscribe_email.html')
